/*
 * Copyright (c) 1997, 2019 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Distribution License v. 1.0, which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

package com.sun.xml.ws.api.message;

import com.sun.xml.ws.api.model.WSDLOperationMapping;

/**
 * In order for the Message to get properties from the Packet ...
 * 
 * @author shih-chang.chen@oracle.com
 */
public interface MessageMetadata {
    public WSDLOperationMapping getWSDLOperationMapping();
}
