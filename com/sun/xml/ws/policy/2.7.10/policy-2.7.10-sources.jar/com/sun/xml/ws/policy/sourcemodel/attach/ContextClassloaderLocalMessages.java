/*
 * Copyright (c) 1997, 2019 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Distribution License v. 1.0, which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

package com.sun.xml.ws.policy.sourcemodel.attach;

import java.util.Locale;
import java.util.ResourceBundle;
import com.sun.istack.localization.Localizable;
import com.sun.istack.localization.LocalizableMessageFactory;
import com.sun.istack.localization.LocalizableMessageFactory.ResourceBundleSupplier;
import com.sun.istack.localization.Localizer;


/**
 * Defines string formatting method for each constant in the resource file
 * 
 */
public final class ContextClassloaderLocalMessages {

    private final static String BUNDLE_NAME = "com.sun.xml.ws.policy.sourcemodel.attach.ContextClassloaderLocal";
    private final static LocalizableMessageFactory MESSAGE_FACTORY = new LocalizableMessageFactory(BUNDLE_NAME, new ContextClassloaderLocalMessages.BundleSupplier());
    private final static Localizer LOCALIZER = new Localizer();

    public static Localizable localizableFAILED_TO_CREATE_NEW_INSTANCE(Object arg0) {
        return MESSAGE_FACTORY.getMessage("FAILED_TO_CREATE_NEW_INSTANCE", arg0);
    }

    /**
     * Failed to create new instance of {0}
     * 
     */
    public static String FAILED_TO_CREATE_NEW_INSTANCE(Object arg0) {
        return LOCALIZER.localize(localizableFAILED_TO_CREATE_NEW_INSTANCE(arg0));
    }

    private static class BundleSupplier
        implements ResourceBundleSupplier
    {


        public ResourceBundle getResourceBundle(Locale locale) {
            return ResourceBundle.getBundle(BUNDLE_NAME, locale);
        }

    }

}
