/*
 * Copyright (c) 2005, 2010, Thai Open Source Software Center Ltd
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 *     Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *     Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *
 *     Neither the name of the Thai Open Source Software Center Ltd nor
 *     the names of its contributors may be used to endorse or promote
 *     products derived from this software without specific prior written
 *     permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.sun.tools.rngdatatype;

/**
 * Creates a user-defined type by adding parameters to
 * the pre-defined type.
 * 
 * @author <a href="mailto:jjc@jclark.com">James Clark</a>
 * @author <a href="mailto:kohsuke.kawaguchi@sun.com">Kohsuke KAWAGUCHI</a>
 */
public interface DatatypeBuilder {
	
	/**
	 * Adds a new parameter.
	 *
	 * @param name
	 *		The name of the parameter to be added.
	 * @param strValue
	 *		The raw value of the parameter. Caller may not normalize
	 *		this value because any white space is potentially significant.
	 * @param context
	 *		The context information which can be used by the callee to
	 *		acquire additional information. This context object is
	 *		valid only during this method call. The callee may not
	 *		keep a reference to this object.
	 * @exception	DatatypeException
	 *		When the given parameter is inappropriate for some reason.
	 *		The callee is responsible to recover from this error.
	 *		That is, the object should behave as if no such error
	 *		was occured.
	 */
	void addParameter(String name, String strValue, ValidationContext context)
		throws DatatypeException;
	
	/**
	 * Derives a new Datatype from a Datatype by parameters that
	 * were already set through the addParameter method.
	 * 
	 * @exception DatatypeException
	 *		DatatypeException must be thrown if the derivation is
	 *		somehow invalid. For example, a required parameter is missing,
	 *		etc. The exception should contain a diagnosis message
	 *		if possible.
	 */
	Datatype createDatatype() throws DatatypeException;
}
