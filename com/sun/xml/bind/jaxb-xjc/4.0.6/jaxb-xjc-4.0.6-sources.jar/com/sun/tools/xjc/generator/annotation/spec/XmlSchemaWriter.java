/*
 * Copyright (c) 2025 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Distribution License v. 1.0, which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */


package com.sun.tools.xjc.generator.annotation.spec;

import com.sun.codemodel.JAnnotationWriter;
import jakarta.xml.bind.annotation.XmlNsForm;
import jakarta.xml.bind.annotation.XmlSchema;


/**
 * <p><b>Auto-generated, do not edit.</b></p>
 * 
 */
public interface XmlSchemaWriter
    extends JAnnotationWriter<XmlSchema>
{


    XmlSchemaWriter namespace(String value);

    XmlNsWriter xmlns();

    XmlSchemaWriter attributeFormDefault(XmlNsForm value);

    XmlSchemaWriter elementFormDefault(XmlNsForm value);

    XmlSchemaWriter location(String value);

}
