/*
 * Copyright (c) 1997, 2022 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Distribution License v. 1.0, which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/**
 * <h2>Code Generator</h2>.
 *
 * This package hosts code for generating CodeModel AST from {@link com.sun.tools.xjc.model Model}
 * classes.
 */
package com.sun.tools.xjc.generator;
