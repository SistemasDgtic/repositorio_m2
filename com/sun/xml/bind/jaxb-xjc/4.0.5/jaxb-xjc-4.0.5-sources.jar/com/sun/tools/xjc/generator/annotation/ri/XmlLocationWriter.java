/*
 * Copyright (c) 2024 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Distribution License v. 1.0, which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */


package com.sun.tools.xjc.generator.annotation.ri;

import com.sun.codemodel.JAnnotationWriter;
import org.glassfish.jaxb.core.annotation.XmlLocation;


/**
 * <p><b>Auto-generated, do not edit.</b></p>
 * 
 */
public interface XmlLocationWriter
    extends JAnnotationWriter<XmlLocation>
{


}
