/*
 * Copyright 2002-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springframework.test.web.servlet.client;

import org.springframework.http.HttpStatusCode;
import org.springframework.test.web.servlet.client.RestTestClient.ResponseSpec;
import org.springframework.test.web.support.AbstractStatusAssertions;

/**
 * Assertions on the response status.
 *
 * @author Rob Worsnop
 * @since 7.0
 * @see ResponseSpec#expectStatus()
 */
public class StatusAssertions extends AbstractStatusAssertions<ExchangeResult, RestTestClient.ResponseSpec> {


	StatusAssertions(ExchangeResult exchangeResult, ResponseSpec responseSpec) {
		super(exchangeResult, responseSpec);
	}


	@Override
	protected HttpStatusCode getStatus() {
		return getExchangeResult().getStatus();
	}

	@Override
	protected void assertWithDiagnostics(Runnable assertion) {
		getExchangeResult().assertWithDiagnostics(assertion);
	}

}
