/*
 * Copyright 2004-2008 the original author or authors.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.binding.convert.converters;

import org.springframework.util.ClassUtils;

/**
 * Converts a textual representation of a class object to a <code>Class</code> instance.
 * 
 * @author Keith Donald
 */
public class StringToClass extends StringToObject {

	private ClassLoader classLoader;

	public StringToClass(ClassLoader classLoader) {
		super(Class.class);
		this.classLoader = classLoader;
	}

	public Object toObject(String string, Class objectClass) throws Exception {
		return ClassUtils.forName(string, classLoader);
	}

	public String toString(Object object) throws Exception {
		Class clazz = (Class) object;
		return clazz.getName();
	}
}