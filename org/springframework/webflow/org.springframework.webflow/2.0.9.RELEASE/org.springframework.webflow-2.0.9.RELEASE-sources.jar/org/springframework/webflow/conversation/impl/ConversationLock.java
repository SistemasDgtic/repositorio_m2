/*
 * Copyright 2004-2008 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.springframework.webflow.conversation.impl;

import java.io.Serializable;

import org.springframework.webflow.conversation.ConversationLockException;

/**
 * A normalized interface for conversation locks, used to obtain exclusive access to a conversation.
 * 
 * @author Keith Donald
 */
public interface ConversationLock extends Serializable {

	/**
	 * Acquire the conversation lock.
	 * @throws ConversationLockException if an exception is thrown attempting to acquire this lock
	 */
	public void lock() throws ConversationLockException;

	/**
	 * Release the conversation lock.
	 */
	public void unlock();
}