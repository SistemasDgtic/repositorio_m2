/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

// Verify the existence of some of the generated classes
File objectFactory = new File( basedir,'target/generated-sources/jaxb/com/example/myschema/ObjectFactory.java' )
assert objectFactory.exists()
File book = new File( basedir,'target/generated-sources/jaxb/com/example/myschema/Book.java' )
assert book.exists()
File library = new File( basedir,'target/generated-sources/jaxb/com/example/myschema/Library.java' )
assert library.exists()

File testSources = new File( basedir,'target/generated-test-sources/jaxb/' )
assert !testSources.exists()

File objectFactoryCompiled = new File( basedir,'target/classes/com/example/myschema/ObjectFactory.class' )
assert objectFactoryCompiled.exists()
File bookCompiled = new File( basedir,'target/classes/com/example/myschema/Book.class' )
assert bookCompiled.exists()
File libraryCompiled = new File( basedir,'target/classes/com/example/myschema/Library.class' )
assert libraryCompiled.exists()
