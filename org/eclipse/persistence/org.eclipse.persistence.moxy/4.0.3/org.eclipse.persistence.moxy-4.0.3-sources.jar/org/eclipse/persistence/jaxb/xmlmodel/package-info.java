/*
 * Copyright (c) 1998, 2020 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0,
 * or the Eclipse Distribution License v. 1.0 which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * SPDX-License-Identifier: EPL-2.0 OR BSD-3-Clause
 */

// Contributors:
// dmccann - June 29/2009 - 2.0 - Initial implementation
@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://www.eclipse.org/eclipselink/xsds/persistence/oxm", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.eclipse.persistence.jaxb.xmlmodel;
