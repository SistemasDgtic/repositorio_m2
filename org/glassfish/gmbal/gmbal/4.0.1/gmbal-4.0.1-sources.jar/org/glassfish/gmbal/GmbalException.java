/*
 * Copyright (c) 2008, 2018 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Distribution License v. 1.0, which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.glassfish.gmbal;

/** Unchecked exception type used for all gmbal exceptions.
 *
 * @author ken
 */
public class GmbalException extends RuntimeException {
    private static final long serialVersionUID = -7478444176079980162L;
    public GmbalException( String msg ) {
        super( msg ) ;
    }

    public GmbalException( String msg, Throwable thr ) {
        super( msg, thr ) ;
    }
}
