/*
 * Copyright 2021-2026 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is located at
 * 
 * http://aws.amazon.com/apache2.0
 * 
 * or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions
 * and limitations under the License.
 */

package software.amazon.awssdk.regions.servicemetadata;

import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import software.amazon.awssdk.annotations.Generated;
import software.amazon.awssdk.annotations.SdkPublicApi;
import software.amazon.awssdk.regions.PartitionEndpointKey;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.regions.ServiceEndpointKey;
import software.amazon.awssdk.regions.ServiceMetadata;
import software.amazon.awssdk.regions.ServicePartitionMetadata;
import software.amazon.awssdk.regions.internal.DefaultServicePartitionMetadata;
import software.amazon.awssdk.regions.internal.util.ServiceMetadataUtils;
import software.amazon.awssdk.utils.ImmutableMap;
import software.amazon.awssdk.utils.Pair;

@Generated("software.amazon.awssdk:codegen")
@SdkPublicApi
public final class BudgetsServiceMetadata implements ServiceMetadata {
    private static final String ENDPOINT_PREFIX = "budgets";

    private static final List<Region> REGIONS = Collections.unmodifiableList(Arrays.asList(Region.of("aws-global"),
            Region.of("aws-cn-global"), Region.of("aws-iso-global"), Region.of("us-iso-east-1"), Region.of("aws-iso-b-global"),
            Region.of("us-isob-east-1"), Region.of("aws-iso-e-global"), Region.of("eu-isoe-west-1"),
            Region.of("aws-iso-f-global"), Region.of("us-isof-south-1")));

    private static final List<ServicePartitionMetadata> PARTITIONS = Collections.unmodifiableList(Arrays.asList(
            new DefaultServicePartitionMetadata("aws", Region.of("aws-global")), new DefaultServicePartitionMetadata("aws-cn",
                    Region.of("aws-cn-global")), new DefaultServicePartitionMetadata("aws-iso", Region.of("aws-iso-global")),
            new DefaultServicePartitionMetadata("aws-iso-b", Region.of("aws-iso-b-global")), new DefaultServicePartitionMetadata(
                    "aws-iso-e", Region.of("aws-iso-e-global")),
            new DefaultServicePartitionMetadata("aws-iso-f", Region.of("aws-iso-f-global"))));

    private static final Map<ServiceEndpointKey, String> SIGNING_REGIONS_BY_REGION = ImmutableMap
            .<ServiceEndpointKey, String> builder()
            .put(ServiceEndpointKey.builder().region(Region.of("aws-global")).build(), "us-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("aws-cn-global")).build(), "cn-northwest-1")
            .put(ServiceEndpointKey.builder().region(Region.of("aws-iso-global")).build(), "us-iso-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-iso-east-1")).build(), "us-iso-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("aws-iso-b-global")).build(), "us-isob-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-isob-east-1")).build(), "us-isob-east-1")
            .put(ServiceEndpointKey.builder().region(Region.of("aws-iso-e-global")).build(), "eu-isoe-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-isoe-west-1")).build(), "eu-isoe-west-1")
            .put(ServiceEndpointKey.builder().region(Region.of("aws-iso-f-global")).build(), "us-isof-south-1")
            .put(ServiceEndpointKey.builder().region(Region.of("us-isof-south-1")).build(), "us-isof-south-1").build();

    private static final Map<Pair<String, PartitionEndpointKey>, String> SIGNING_REGIONS_BY_PARTITION = ImmutableMap
            .<Pair<String, PartitionEndpointKey>, String> builder().build();

    private static final Map<ServiceEndpointKey, String> DNS_SUFFIXES_BY_REGION = ImmutableMap
            .<ServiceEndpointKey, String> builder().build();

    private static final Map<Pair<String, PartitionEndpointKey>, String> DNS_SUFFIXES_BY_PARTITION = ImmutableMap
            .<Pair<String, PartitionEndpointKey>, String> builder().build();

    private static final Map<ServiceEndpointKey, String> HOSTNAMES_BY_REGION = ImmutableMap
            .<ServiceEndpointKey, String> builder().allowDuplicateKeys(true)
            .put(ServiceEndpointKey.builder().region(Region.of("aws-global")).build(), "budgets.amazonaws.com")
            .put(ServiceEndpointKey.builder().region(Region.of("aws-cn-global")).build(), "budgets.amazonaws.com.cn")
            .put(ServiceEndpointKey.builder().region(Region.of("aws-iso-global")).build(), "budgets.c2s.ic.gov")
            .put(ServiceEndpointKey.builder().region(Region.of("us-iso-east-1")).build(), "budgets.c2s.ic.gov")
            .put(ServiceEndpointKey.builder().region(Region.of("aws-iso-b-global")).build(), "budgets.global.sc2s.sgov.gov")
            .put(ServiceEndpointKey.builder().region(Region.of("us-isob-east-1")).build(), "budgets.global.sc2s.sgov.gov")
            .put(ServiceEndpointKey.builder().region(Region.of("aws-iso-e-global")).build(), "budgets.global.cloud.adc-e.uk")
            .put(ServiceEndpointKey.builder().region(Region.of("eu-isoe-west-1")).build(), "budgets.global.cloud.adc-e.uk")
            .put(ServiceEndpointKey.builder().region(Region.of("aws-iso-f-global")).build(), "budgets.global.csp.hci.ic.gov")
            .put(ServiceEndpointKey.builder().region(Region.of("us-isof-south-1")).build(), "budgets.global.csp.hci.ic.gov")
            .build();

    private static final Map<Pair<String, PartitionEndpointKey>, String> HOSTNAMES_BY_PARTITION = ImmutableMap
            .<Pair<String, PartitionEndpointKey>, String> builder().build();

    @Override
    public List<Region> regions() {
        return REGIONS;
    }

    @Override
    public List<ServicePartitionMetadata> servicePartitions() {
        return PARTITIONS;
    }

    @Override
    public URI endpointFor(ServiceEndpointKey key) {
        return ServiceMetadataUtils.endpointFor(ServiceMetadataUtils.hostname(key, HOSTNAMES_BY_REGION, HOSTNAMES_BY_PARTITION),
                ENDPOINT_PREFIX, key.region().id(),
                ServiceMetadataUtils.dnsSuffix(key, DNS_SUFFIXES_BY_REGION, DNS_SUFFIXES_BY_PARTITION));
    }

    @Override
    public Region signingRegion(ServiceEndpointKey key) {
        return ServiceMetadataUtils.signingRegion(key, SIGNING_REGIONS_BY_REGION, SIGNING_REGIONS_BY_PARTITION);
    }
}
